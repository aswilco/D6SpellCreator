﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using D6SpellCreator.Models;

namespace D6SpellCreator.Services
{
    public class MockDataStore : IDataStore<Spell>
    {
        List<Spell> items;

        public MockDataStore()
        {
            items = new List<Spell>();
        }

        public async Task<bool> AddItemAsync(Spell item)
        {
            items.Add(item);
            return await Task.FromResult(true);
        }

        public async Task<bool> UpdateItemAsync(Spell item)
        {
            var oldItem = items.Where((Spell arg) => arg.Name == item.Name).FirstOrDefault();
            items.Remove(oldItem);
            items.Add(item);

            return await Task.FromResult(true);
        }

        public async Task<bool> DeleteItemAsync(string name)
        {
            var oldItem = items.Where((Spell arg) => arg.Name == name).FirstOrDefault();
            items.Remove(oldItem);

            return await Task.FromResult(true);
        }

        public async Task<Spell> GetItemAsync(string name)
        {
            return await Task.FromResult(items.FirstOrDefault(s => s.Name == name));
        }

        public async Task<IEnumerable<Spell>> GetItemsAsync(bool forceRefresh = false)
        {
            return await Task.FromResult(items);
        }
    }
}